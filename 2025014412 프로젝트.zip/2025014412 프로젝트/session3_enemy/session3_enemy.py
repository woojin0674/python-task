﻿import random
import math

class EnemySession:
    def __init__(self, canvas, bullet_session, health_session, sound):
        self.canvas = canvas
        self.bullet_session = bullet_session
        self.health_session = health_session
        self.sound = sound

        self.enemies = []
        self.SPAWN_INTERVAL = 800

    def spawn_enemy(self):
        x = self.canvas.winfo_width() + 40
        y = random.randint(80, 520)

        enemy_id = self.canvas.create_rectangle(
            x - 30, y - 30, x + 30, y + 30,
            fill="red"
        )

        enemy = {
            "id": enemy_id,
            "hp": 3,
            "speed": 6
        }

        self.enemies.append(enemy)
        self.canvas.after(self.SPAWN_INTERVAL, self.spawn_enemy)

    def update_enemies(self):
        player = self.bullet_session.player
        player_bbox = self.canvas.bbox(player.player)

        for enemy in self.enemies[:]:
            eid = enemy["id"]
            self.canvas.move(eid, -enemy["speed"], 0)
            enemy_bbox = self.canvas.bbox(eid)

            # 총알 충돌
            for bullet in self.bullet_session.bullets[:]:
                bullet_bbox = self.canvas.bbox(bullet)
                if bullet_bbox and enemy_bbox and self.check_collision(enemy_bbox, bullet_bbox):
                    enemy["hp"] -= 1
                    self.canvas.delete(bullet)
                    self.bullet_session.bullets.remove(bullet)

                    self.sound.play("hit")  # ✅ 피격 소리만

                    if enemy["hp"] <= 0:
                        self.canvas.delete(eid)
                        self.enemies.remove(enemy)
                    break

            # 플레이어 충돌
            if player_bbox and enemy_bbox and self.check_collision(enemy_bbox, player_bbox):
                if player.take_hit():
                    self.health_session.reduce_hp()
                self.canvas.delete(eid)
                self.enemies.remove(enemy)

        self.canvas.after(16, self.update_enemies)

    @staticmethod
    def check_collision(a, b):
        return (
            a[0] < b[2] and a[2] > b[0] and
            a[1] < b[3] and a[3] > b[1]
        )

    def start(self):
        self.spawn_enemy()
        self.update_enemies()
