﻿from PIL import Image, ImageTk
import random

class PowerUpSession:
    def __init__(self, canvas, player_session, bullet_session):
        self.canvas = canvas
        self.player_session = player_session
        self.bullet_session = bullet_session
        self.items = []

        self.SPAWN_INTERVAL = 10000

        try:
            img = Image.open("assets/powerup.png")
            img = img.resize((30, 30))
            self.powerup_photo = ImageTk.PhotoImage(img)
        except:
            self.powerup_photo = None

        self.active = False
        self.original_fire_interval = self.bullet_session.FIRE_INTERVAL

    # 🔒 안전한 Y 좌표
    def safe_random_y(self):
        h = self.canvas.winfo_height()
        if h < 120:
            return 250
        return random.randint(50, h - 50)

    def spawn_powerup(self):
        x = self.canvas.winfo_width() + 20
        y = self.safe_random_y()

        item = self.canvas.create_image(x, y, image=self.powerup_photo)
        self.items.append(item)

        self.canvas.after(self.SPAWN_INTERVAL, self.spawn_powerup)

    def update_powerups(self):
        for item in self.items[:]:
            self.canvas.move(item, -5, 0)
            bbox = self.canvas.bbox(item)

            if bbox and bbox[2] < 0:
                self.canvas.delete(item)
                self.items.remove(item)
                continue

            player_bbox = self.canvas.bbox(self.player_session.player)
            if player_bbox and bbox and self.check_collision(player_bbox, bbox):
                self.apply_powerup()
                self.canvas.delete(item)
                self.items.remove(item)

        self.canvas.after(16, self.update_powerups)

    def apply_powerup(self):
        if self.active:
            return
        self.active = True
        self.bullet_session.FIRE_INTERVAL = 100
        self.canvas.after(800, self.remove_powerup)

    def remove_powerup(self):
        self.bullet_session.FIRE_INTERVAL = self.original_fire_interval
        self.active = False

    @staticmethod
    def check_collision(a, b):
        return (
            a[0] < b[2] and a[2] > b[0] and
            a[1] < b[3] and a[3] > b[1]
        )

    def start(self):
        self.canvas.after(1000, self.spawn_powerup)
        self.update_powerups()
