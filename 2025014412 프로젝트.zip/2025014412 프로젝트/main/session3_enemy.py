from PIL import Image, ImageTk
import os, random, math

# ✅ 난이도 '중상'
BASE_SPAWN_INTERVAL = 420
MIN_SPAWN_INTERVAL  = 200
SPAWN_RAMP_STEP     = 20
DIFF_RAMP_EVERY_MS  = 7000

BASE_SPAWN_COUNT = 1
MAX_SPAWN_COUNT  = 3

# ✅ 플레이어 히트박스 줄이기(픽셀) - 값 클수록 더 작아짐
PLAYER_HITBOX_INSET = 16  # 10~22 정도 추천

ENEMY_TYPES = {
    "light": {"hp": 1, "speed": 13, "pattern": "straight", "img": "light.png"},
    "fast":  {"hp": 1, "speed": 19, "pattern": "zigzag",  "img": "fast.png"},
    "tank":  {"hp": 5, "speed": 6,  "pattern": "straight", "img": "tank.png"},
}

def _overlap(a, b):
    return (a[0] < b[2] and a[2] > b[0] and a[1] < b[3] and a[3] > b[1])

def _inset_bbox(bb, inset):
    if not bb:
        return None
    x1, y1, x2, y2 = bb
    x1 += inset
    y1 += inset
    x2 -= inset
    y2 -= inset
    # 너무 줄여서 뒤집히면 최소 박스로 보정
    if x2 <= x1:
        cx = (bb[0] + bb[2]) / 2
        x1, x2 = cx - 1, cx + 1
    if y2 <= y1:
        cy = (bb[1] + bb[3]) / 2
        y1, y2 = cy - 1, cy + 1
    return (x1, y1, x2, y2)

class EnemySession:
    def __init__(self, canvas, player, bullet, health, sound, game_over_cb):
        self.canvas = canvas
        self.player = player
        self.bullet = bullet
        self.health = health
        self.sound = sound
        self.game_over_cb = game_over_cb

        self.enemies = []
        self.spawn_int = BASE_SPAWN_INTERVAL
        self.spawn_count = BASE_SPAWN_COUNT
        self.speed_bonus = 0

        self.running = False
        self._spawn_after_id = None
        self._update_after_id = None
        self._ramp_after_id = None

        self.score = 0
        self.score_text = self.canvas.create_text(
            10, 10, anchor="nw", fill="white", font=("Arial", 16),
            text=f"Score: {self.score}"
        )

        base = os.path.dirname(__file__)
        self.images = {}
        for k, v in ENEMY_TYPES.items():
            img = Image.open(os.path.join(base, "assets", "enemies", v["img"])).resize((70, 70))
            self.images[k] = ImageTk.PhotoImage(img)

    def _set_score(self, v):
        self.score = v
        self.canvas.itemconfig(self.score_text, text=f"Score: {self.score}")

    def _ramp_difficulty(self):
        if not self.running:
            return
        self.spawn_int = max(MIN_SPAWN_INTERVAL, self.spawn_int - SPAWN_RAMP_STEP)
        self.spawn_count = min(MAX_SPAWN_COUNT, self.spawn_count + 1)
        self.speed_bonus += 1
        self._ramp_after_id = self.canvas.after(DIFF_RAMP_EVERY_MS, self._ramp_difficulty)

    def _spawn_one(self):
        h = self.canvas.winfo_height()
        w = self.canvas.winfo_width()
        et = random.choice(list(ENEMY_TYPES.keys()))
        info = ENEMY_TYPES[et]
        x = w + random.randint(20, 80)
        y = random.randint(60, h - 60)
        speed = info["speed"] + self.speed_bonus
        eid = self.canvas.create_image(x, y, image=self.images[et])
        self.enemies.append({
            "id": eid,
            "hp": info["hp"],
            "speed": speed,
            "pattern": info["pattern"],
            "angle": random.uniform(0, math.tau),
        })

    def spawn(self):
        if not self.running:
            return
        h = self.canvas.winfo_height()
        w = self.canvas.winfo_width()
        if h < 140 or w < 140:
            self._spawn_after_id = self.canvas.after(50, self.spawn)
            return

        for _ in range(self.spawn_count):
            self._spawn_one()

        self._spawn_after_id = self.canvas.after(self.spawn_int, self.spawn)

    def _kill_enemy(self, e):
        try:
            self.canvas.delete(e["id"])
        except Exception:
            pass
        if e in self.enemies:
            self.enemies.remove(e)

    def update(self):
        if not self.running:
            return
        h = self.canvas.winfo_height()

        # ✅ 플레이어 히트박스 축소
        pb_raw = self.canvas.bbox(self.player.player)
        pb = _inset_bbox(pb_raw, PLAYER_HITBOX_INSET)

        for e in self.enemies[:]:
            if e["pattern"] == "zigzag":
                dy = math.sin(e["angle"]) * 6
                e["angle"] += 0.42
                x, y = self.canvas.coords(e["id"])
                if y < 70:
                    dy = abs(dy)
                elif y > h - 70:
                    dy = -abs(dy)
                self.canvas.move(e["id"], -e["speed"], dy)
            else:
                self.canvas.move(e["id"], -e["speed"], 0)

            eb = self.canvas.bbox(e["id"])
            if not eb:
                continue

            # 플레이어 충돌(축소된 히트박스 기준)
            if pb and _overlap(eb, pb):
                if self.player.take_hit():
                    self.health.reduce_hp()
                    if self.health.hp <= 0:
                        self.running = False
                        self.game_over_cb()
                        return
                self._kill_enemy(e)
                continue

            # 총알 충돌
            for b in self.bullet.bullets[:]:
                bb = self.canvas.bbox(b)
                if bb and _overlap(eb, bb):
                    e["hp"] -= 1
                    self.canvas.delete(b)
                    self.bullet.bullets.remove(b)
                    self.sound.play("hit")
                    if e["hp"] <= 0:
                        self._kill_enemy(e)
                        self._set_score(self.score + 1)
                    break

            if eb[2] < 0:
                self._kill_enemy(e)

        self._update_after_id = self.canvas.after(16, self.update)

    def start(self):
        if self.running:
            return
        self.running = True
        self.spawn()
        self.update()
        self._ramp_difficulty()

    def stop(self):
        self.running = False
        for aid in (self._spawn_after_id, self._update_after_id, self._ramp_after_id):
            if aid is not None:
                try:
                    self.canvas.after_cancel(aid)
                except Exception:
                    pass
        self._spawn_after_id = None
        self._update_after_id = None
        self._ramp_after_id = None
        for e in self.enemies[:]:
            self._kill_enemy(e)
