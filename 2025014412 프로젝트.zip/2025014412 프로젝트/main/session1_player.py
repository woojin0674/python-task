
from PIL import Image, ImageTk
import os, time

class PlayerSession:
    def __init__(self, canvas, sound):
        self.canvas = canvas
        self.sound = sound
        self.inv_until = 0.0
        self.INV = 0.8

        base = os.path.dirname(__file__)
        img = Image.open(os.path.join(base, "assets", "player.png")).resize((70,70))
        self.tkimg = ImageTk.PhotoImage(img)
        self.player = self.canvas.create_image(150, 300, image=self.tkimg)

        self.canvas.bind("<Motion>", self.move)

    def move(self, e):
        self.canvas.coords(self.player, e.x, e.y)

    def take_hit(self):
        now = time.time()
        if now < self.inv_until:
            return False
        self.inv_until = now + self.INV
        self.sound.play("player_hit")
        return True
