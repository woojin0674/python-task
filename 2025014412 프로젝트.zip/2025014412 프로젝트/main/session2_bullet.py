from PIL import Image, ImageTk
import os, time

class BulletSession:
    def __init__(self, canvas, player, sound):
        self.canvas = canvas
        self.player = player
        self.sound = sound
        self.bullets = []
        self.last = 0

        # ✅ 기본 발사 간격(파워업 끝나면 여기로 복귀)
        self.DEFAULT_INTERVAL = 300
        self.INTERVAL = self.DEFAULT_INTERVAL

        self.SPEED = 12

        self.running = False
        self._after_id = None

        base = os.path.dirname(__file__)
        img = Image.open(os.path.join(base, "assets", "bullets", "player_bullet.png")).resize((20,10))
        self.tkimg = ImageTk.PhotoImage(img)

    def fire(self):
        if not self.running:
            return
        x, y = self.canvas.coords(self.player.player)
        b = self.canvas.create_image(x+20, y, image=self.tkimg)
        self.bullets.append(b)
        self.sound.play("shoot")

    def update(self):
        if not self.running:
            return

        now = int(time.time()*1000)
        if now - self.last >= self.INTERVAL:
            self.fire()
            self.last = now

        for b in self.bullets[:]:
            self.canvas.move(b, self.SPEED, 0)
            bb = self.canvas.bbox(b)
            if bb and bb[0] > self.canvas.winfo_width():
                self.canvas.delete(b)
                self.bullets.remove(b)

        self._after_id = self.canvas.after(16, self.update)

    def start(self):
        if self.running:
            return
        self.running = True
        self.last = 0
        self.update()

    def stop(self):
        self.running = False
        if self._after_id is not None:
            try:
                self.canvas.after_cancel(self._after_id)
            except Exception:
                pass
            self._after_id = None

    def reset_fire_rate(self):
        """✅ 파워업 종료 시 호출"""
        self.INTERVAL = self.DEFAULT_INTERVAL
