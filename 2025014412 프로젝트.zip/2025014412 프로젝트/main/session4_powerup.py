from PIL import Image, ImageTk
import os, random, time

class PowerUpSession:
    def __init__(self, canvas, player, bullet):
        self.canvas = canvas
        self.player = player
        self.bullet = bullet
        self.items = []

        self.running = False
        self._spawn_after_id = None
        self._update_after_id = None

        # ✅ 파워업 지속시간(ms)
        self.BUFF_DURATION = 5000
        self._buff_until_ms = 0
        self._restore_after_id = None

        base = os.path.dirname(__file__)
        img = Image.open(os.path.join(base, "assets", "powerup.png")).resize((30, 30))
        self.tkimg = ImageTk.PhotoImage(img)

    def spawn(self):
        if not self.running:
            return

        h = self.canvas.winfo_height()
        w = self.canvas.winfo_width()
        if h < 140 or w < 140:
            self._spawn_after_id = self.canvas.after(50, self.spawn)
            return

        x = w + 20
        y = random.randint(60, h - 60)

        i = self.canvas.create_image(x, y, image=self.tkimg)
        self.items.append(i)
        self._spawn_after_id = self.canvas.after(10000, self.spawn)

    def _apply_buff(self):
        # ✅ 파워업: 발사 간격 빠르게(작을수록 빠름)
        self.bullet.INTERVAL = 120

        # ✅ 시간 연장(연속 먹으면 지속시간 늘어남)
        now = int(time.time() * 1000)
        self._buff_until_ms = max(self._buff_until_ms, now) + self.BUFF_DURATION

        # 기존 예약 취소 후 다시 예약
        if self._restore_after_id is not None:
            try:
                self.canvas.after_cancel(self._restore_after_id)
            except Exception:
                pass

        delay = max(0, self._buff_until_ms - now)
        self._restore_after_id = self.canvas.after(delay, self._restore_buff)

    def _restore_buff(self):
        self._restore_after_id = None
        # ✅ 파워업 종료: 원래 총알 속도로 복귀
        if hasattr(self.bullet, "reset_fire_rate"):
            self.bullet.reset_fire_rate()
        else:
            # 안전장치
            self.bullet.INTERVAL = getattr(self.bullet, "DEFAULT_INTERVAL", 300)

    def update(self):
        if not self.running:
            return

        px, py = self.canvas.coords(self.player.player)

        for i in self.items[:]:
            self.canvas.move(i, -4, 0)
            ib = self.canvas.bbox(i)
            if ib and ib[2] < 0:
                self.canvas.delete(i)
                self.items.remove(i)
                continue

            # 간단 충돌(근사)
            if ib and abs(ib[0] - px) < 30 and abs(ib[1] - py) < 30:
                self._apply_buff()
                self.canvas.delete(i)
                self.items.remove(i)

        self._update_after_id = self.canvas.after(16, self.update)

    def start(self):
        if self.running:
            return
        self.running = True
        self.spawn()
        self.update()

    def stop(self):
        self.running = False
        for aid in (self._spawn_after_id, self._update_after_id, self._restore_after_id):
            if aid is not None:
                try:
                    self.canvas.after_cancel(aid)
                except Exception:
                    pass
        self._spawn_after_id = None
        self._update_after_id = None
        self._restore_after_id = None
        for i in self.items[:]:
            try:
                self.canvas.delete(i)
            except Exception:
                pass
        self.items.clear()
