import tkinter as tk
from sound_manager import SoundManager
from session1_player import PlayerSession
from session2_bullet import BulletSession
from session3_enemy import EnemySession
from session4_powerup import PowerUpSession
from session5_health import HealthSession

WIDTH, HEIGHT = 900, 600

class GameApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Space Shooting Game")

        self.canvas = tk.Canvas(self.root, width=WIDTH, height=HEIGHT, bg="black", highlightthickness=0)
        self.canvas.pack()

        self.sound = SoundManager()
        self.sound.play_bgm("assets/sounds/space_bgm.wav")

        self.start_new_game()

    def start_new_game(self):
        self.canvas.delete("all")

        self.player = PlayerSession(self.canvas, self.sound)
        self.bullet = BulletSession(self.canvas, self.player, self.sound)
        self.health = HealthSession(self.canvas, self.player)
        self.enemy = EnemySession(self.canvas, self.player, self.bullet, self.health, self.sound, self.on_game_over)
        self.powerup = PowerUpSession(self.canvas, self.player, self.bullet)

        self.bullet.start()
        self.enemy.start()
        self.powerup.start()

    def on_game_over(self):
        for s in (self.bullet, self.enemy, self.powerup):
            try:
                s.stop()
            except Exception:
                pass

        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        self.canvas.create_text(w//2, h//2 - 20, fill="white", font=("Arial", 36, "bold"), text="GAME OVER")
        self.canvas.create_text(w//2, h//2 + 30, fill="white", font=("Arial", 18), text="Click to Restart")

        self.canvas.bind("<Button-1>", self._restart_click)

    def _restart_click(self, _evt):
        self.canvas.unbind("<Button-1>")
        self.start_new_game()

    def run(self):
        self.root.mainloop()

def run_game():
    GameApp().run()

if __name__ == "__main__":
    run_game()
