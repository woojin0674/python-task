
import pygame

class SoundManager:
    def __init__(self):
        pygame.mixer.init()
        self.sounds = {}
        self.load("shoot","assets/sounds/shoot.wav")
        self.load("hit","assets/sounds/hit.wav")
        self.load("player_hit","assets/sounds/player_hit.wav")

    def load(self,k,p):
        try: self.sounds[k]=pygame.mixer.Sound(p)
        except: pass

    def play(self,k):
        if k in self.sounds: self.sounds[k].play()

    def play_bgm(self,p):
        try:
            pygame.mixer.music.load(p)
            pygame.mixer.music.play(-1)
        except: pass
