
from PIL import Image, ImageTk
import os, tkinter as tk

class HealthSession:
    def __init__(self, canvas, player):
        self.canvas = canvas
        self.player = player
        self.hp = 3

        base = os.path.dirname(__file__)
        img = Image.open(os.path.join(base,"assets","heart.png")).resize((30,30))
        self.tkimg = ImageTk.PhotoImage(img)
        self.hearts = []
        self.draw()

    def draw(self):
        for h in self.hearts: self.canvas.delete(h)
        self.hearts.clear()
        for i in range(self.hp):
            self.hearts.append(self.canvas.create_image(10+i*35,40,anchor="nw",image=self.tkimg))

    def reduce_hp(self):
        self.hp-=1; self.draw()
