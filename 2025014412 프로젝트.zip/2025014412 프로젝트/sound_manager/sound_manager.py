﻿import pygame

class SoundManager:
    def __init__(self):
        pygame.mixer.init()
        pygame.mixer.set_num_channels(8)

        self.sounds = {}

        self.load("shoot", "assets/sounds/shoot.wav")
        self.load("hit", "assets/sounds/hit.wav")
        self.load("player_hit", "assets/sounds/player_hit.wav")
        # ❌ explosion 없음

    def load(self, key, path):
        try:
            self.sounds[key] = pygame.mixer.Sound(path)
        except Exception as e:
            print("사운드 로드 실패:", path, e)

    def play(self, key):
        if key in self.sounds:
            self.sounds[key].play()

    def play_bgm(self, path, volume=0.4):
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(volume)
            pygame.mixer.music.play(-1)
        except Exception as e:
            print("BGM 실패:", e)

    def stop_bgm(self):
        pygame.mixer.music.stop()
