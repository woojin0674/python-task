﻿from PIL import Image, ImageTk
import os
import time

class PlayerSession:
    def __init__(self, canvas, sound):
        self.canvas = canvas
        self.sound = sound

        self.invincible_time = 0
        self.INVINCIBLE_DURATION = 0.8

        BASE_DIR = os.path.dirname(__file__)

        try:
            img = Image.open(
                os.path.join(BASE_DIR, "assets", "player.png")
            ).resize((70, 70))
            self.image = ImageTk.PhotoImage(img)
            self.player = self.canvas.create_image(
                150, 300, image=self.image
            )
        except:
            self.player = self.canvas.create_rectangle(
                120, 270, 180, 330, fill="blue"
            )

        # 🔥 마우스 이동 바인딩 (중요)
        self.canvas.bind("<Motion>", self.move_mouse)

    def move_mouse(self, event):
        self.canvas.coords(self.player, event.x, event.y)

    def take_hit(self):
        now = time.time()
        if now < self.invincible_time:
            return False

        self.invincible_time = now + self.INVINCIBLE_DURATION
        return True
