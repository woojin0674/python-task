from PIL import Image, ImageTk
import tkinter as tk

class HealthSession:
    def __init__(self, canvas, player_session, enemy_session=None):
        self.canvas = canvas
        self.player_session = player_session
        self.enemy_session = enemy_session

        self.max_hp = 3
        self.current_hp = 3
        self.game_over = False

        try:
            img = Image.open("assets/heart.png").resize((30, 30))
            self.heart_photo = ImageTk.PhotoImage(img)
        except:
            self.heart_photo = None

        self.hp_images = []
        self.draw_hp()

    def draw_hp(self):
        for img in self.hp_images:
            self.canvas.delete(img)
        self.hp_images.clear()

        for i in range(self.current_hp):
            x = 10 + i * 35
            y = 40
            self.hp_images.append(
                self.canvas.create_image(x, y, anchor="nw", image=self.heart_photo)
            )

    def reduce_hp(self):
        if self.game_over:
            return
        self.current_hp -= 1
        self.draw_hp()
        if self.current_hp <= 0:
            self.trigger_game_over()

    def trigger_game_over(self):
        self.game_over = True
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()

        self.canvas.create_text(w//2, h//2 - 60, text="GAME OVER",
                                fill="red", font=("Arial", 50, "bold"))
        score = getattr(self.enemy_session, "score", 0)
        self.canvas.create_text(w//2, h//2, text=f"Score: {score}",
                                fill="white", font=("Arial", 30))

        tk.Button(self.canvas.master, text="Retry", font=("Arial", 18),
                  command=self.retry).place(x=w//2 - 70, y=h//2 + 40)

    def retry(self):
        import main
        self.canvas.master.destroy()
        main.run_game()

    def start(self):
        self.draw_hp()
