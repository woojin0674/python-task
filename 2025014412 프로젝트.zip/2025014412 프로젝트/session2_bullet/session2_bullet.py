﻿import time

class BulletSession:
    def __init__(self, canvas, player, sound):
        self.canvas = canvas
        self.player = player
        self.sound = sound

        self.bullets = []
        self.FIRE_INTERVAL = 300
        self.BULLET_SPEED = 12
        self.last_fire_time = 0

    def fire_bullet(self):
        bbox = self.canvas.bbox(self.player.player)
        if not bbox:
            return

        x1, y1, x2, y2 = bbox
        x = x2 + 10
        y = (y1 + y2) / 2

        bullet = self.canvas.create_oval(
            x - 4, y - 4, x + 4, y + 4,
            fill="white"
        )
        self.bullets.append(bullet)
        self.sound.play("shoot")

    def update(self):
        now = int(time.time() * 1000)

        if now - self.last_fire_time >= self.FIRE_INTERVAL:
            self.fire_bullet()
            self.last_fire_time = now

        for bullet in self.bullets[:]:
            self.canvas.move(bullet, self.BULLET_SPEED, 0)
            bbox = self.canvas.bbox(bullet)
            if bbox and bbox[0] > self.canvas.winfo_width():
                self.canvas.delete(bullet)
                self.bullets.remove(bullet)

        self.canvas.after(16, self.update)

    def start(self):
        self.update()
